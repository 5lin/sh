// ==UserScript==
// @name         hook-loadjs-disable-disable-devtool
// @namespace    http://tampermonkey.net/
// @version      2025-07-09
// @description  try to take over the world!
// @author       You
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=chinamobile.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    console.clear = ()=>{
console.log('console.clear()');
    };

    Object.defineProperty(window, 'loadjs', {
        set(val_loadjs) {
            // 检查是不是你要拦截的对象
            //debugger;
            console.log('set loadjs = ',val_loadjs);

            Object.defineProperty(val_loadjs, 'd', {
                set(val_d) {
                    // 检查是不是你要拦截的对象
                    //debugger;
                    console.log('set loadjs.d = ',val_d);

                    let hook_val_d = new Proxy(val_d, {
                        apply(target, thisArg, argumentsList) {
                            // 显示参数

                            console.log('loadjs.d args:', argumentsList);
                            let oldargfn = argumentsList[1];
                            argumentsList[1] = (fnLoadModule,b,c)=>{

                                let hookfn_loadmodule = new Proxy(fnLoadModule,{
                                    apply(target2, thisArg2,[moduleName,...rest]){
                                        console.log('load module:',moduleName);

                                        const result2 = Reflect.apply(target2, thisArg2, [moduleName,...rest]);
                                        console.log('loaded module:',moduleName, result2);
                                        // 修改返回值
                                        if(moduleName == "disable-devtool"){
                                            //debugger;
                                            let disable_devtool = result2;
                                            const hook_result2 = (conf)=>{
                                                console.log('disable_devtool:(',conf,')');
                                                conf = {
                                                    clearIntervalWhenDevOpenTrigger: true,
                                                    ondevtoolopen: function() {
                                                        console.log("about:blank", "_self")
                                                    },
                                                    detectors: []
                                                }

                                                return disable_devtool(conf);
                                            };

                                            return hook_result2;
                                        }
                                        return result2;
                                    }

                                });


                                let ret = oldargfn(hookfn_loadmodule,b,c);
                                console.log('define module:',ret);
                                return ret;
                            };

                            // 调用原函数
                            const result = Reflect.apply(target, thisArg, argumentsList);

                            // 修改返回值
                            return result;
                        }
                    });

                    // 真正赋值
                    Object.defineProperty(val_loadjs, 'd', {
                        value: hook_val_d,
                        writable: true,
                        configurable: true,
                        enumerable: true
                    });
                },
                configurable: true
            });




            // 真正赋值
            Object.defineProperty(window, 'loadjs', {
                value: val_loadjs,
                writable: true,
                configurable: true,
                enumerable: true
            });
        },
        configurable: true
    });

})();