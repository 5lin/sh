/**
 * 多语言支持模块
 */

const translations = {
    zh: {
        // Header
        title: 'Tron Fee Calculator',
        subtitle: '实时手续费估算工具',
        connecting: '连接中...',
        connected: '已连接',
        connectionFailed: '连接失败',

        // Live Data
        trxPriceLabel: 'TRX 价格',
        energyPriceLabel: '能量单价',
        bandwidthPriceLabel: '带宽单价',
        lastUpdateLabel: '更新时间',

        // Transfer Types
        trxTransfer: 'TRX 转账',
        trxDesc: '原生代币转账',
        usdtTransfer: 'USDT 转账',
        usdtDesc: 'TRC20 代币转账',

        // Address Section
        recipientAddress: '接收方地址',
        addressDesc: '输入地址自动检测是否已持有 USDT',
        checkBtn: '检测',
        checking: '检测中...',
        hasUsdtStatus: '✓ 该地址已持有 USDT，费用较低',
        noUsdtStatus: '✕ 该地址未持有 USDT，需支付更多能量',
        invalidAddress: '⚠️ 地址格式无效',
        checkFailed: '⚠️ 检测失败，请手动选择',

        // Amount Section
        transferAmount: '转账金额',
        amountDesc: '输入金额计算手续费占比',
        feeRatioText: '手续费占转账金额的 {ratio}%',

        // Wallet Status
        walletStatus: '接收方钱包状态',
        walletStatusDesc: '首次接收 USDT 的钱包需要创建代币账户，消耗更多能量',
        hasUsdt: '已有 USDT',
        noUsdt: '首次接收',
        energy: '能量',

        // Results
        feeEstimate: '手续费估算',
        resourceConsumption: '资源消耗',
        bandwidth: '带宽 (Bandwidth)',
        bandwidthDesc: '用于交易数据传输',
        energyLabel: '能量 (Energy)',
        energyDesc: '用于智能合约执行',
        estimatedFee: '预计费用',
        bandwidthFee: '带宽费用',
        energyFee: '能量费用',
        total: '总计',

        // Rental Comparison
        costComparison: '💡 能量租赁 vs 直接燃烧对比',
        directBurn: '直接燃烧 TRX',
        energyRental: '能量租赁',
        rentalNote: '* 能量租赁价格基于市场平均估算值',

        // Staking Calculator
        stakingTitle: '质押 TRX 获取能量',
        stakingDesc: '长期持有者可通过质押 TRX 获取免费能量，无需每次支付手续费',
        requiredStake: '需要质押',
        dailyTransfers: '每日可转账',
        times: '次',
        energyRecovery: '能量每24小时恢复',
        breakEven: '回本周期',
        days: '天',
        breakEvenNote: '按每日1笔转账计算',
        burnMethod: '🔥 燃烧 TRX',
        burnMethodDesc: '每笔支付，无需锁仓',
        stakeMethod: '🔒 质押 TRX',
        stakeMethodDesc: '长期持有最划算',
        recommended: '推荐',
        rentMethod: '⚡ 能量租赁',
        rentMethodDesc: '灵活省钱，无需锁仓',

        // Tips
        tip: '省钱小贴士',
        trxTip: 'TRX 转账仅消耗带宽，每个账户每天有 600 免费带宽额度。如果带宽不足，将自动燃烧 TRX 支付。',
        usdtTipHas: 'USDT (TRC20) 转账需要能量和带宽。可以通过质押 TRX 获取免费能量，或者使用第三方能量租赁服务节省 60%-90% 费用。',
        usdtTipNo: '首次接收 USDT 需要创建代币账户，消耗约 2 倍能量。建议先向目标地址发送少量 USDT 激活账户，后续转账费用将降低一半。',

        // Footer
        dataSource: '数据来源：',
        disclaimer: '⚠️ 以上费用仅为估算值，实际费用可能因网络状况略有差异',
    },
    en: {
        // Header
        title: 'Tron Fee Calculator',
        subtitle: 'Real-time Fee Estimation Tool',
        connecting: 'Connecting...',
        connected: 'Connected',
        connectionFailed: 'Connection Failed',

        // Live Data
        trxPriceLabel: 'TRX Price',
        energyPriceLabel: 'Energy Price',
        bandwidthPriceLabel: 'Bandwidth Price',
        lastUpdateLabel: 'Last Update',

        // Transfer Types
        trxTransfer: 'TRX Transfer',
        trxDesc: 'Native Token Transfer',
        usdtTransfer: 'USDT Transfer',
        usdtDesc: 'TRC20 Token Transfer',

        // Address Section
        recipientAddress: 'Recipient Address',
        addressDesc: 'Enter address to auto-detect USDT holdings',
        checkBtn: 'Check',
        checking: 'Checking...',
        hasUsdtStatus: '✓ Address holds USDT, lower fee applies',
        noUsdtStatus: '✕ Address does not hold USDT, higher energy cost',
        invalidAddress: '⚠️ Invalid address format',
        checkFailed: '⚠️ Check failed, please select manually',

        // Amount Section
        transferAmount: 'Transfer Amount',
        amountDesc: 'Enter amount to calculate fee ratio',
        feeRatioText: 'Fee is {ratio}% of transfer amount',

        // Wallet Status
        walletStatus: 'Recipient Wallet Status',
        walletStatusDesc: 'First-time USDT recipients need token account creation, consuming more energy',
        hasUsdt: 'Has USDT',
        noUsdt: 'First Time',
        energy: 'Energy',

        // Results
        feeEstimate: 'Fee Estimate',
        resourceConsumption: 'Resource Consumption',
        bandwidth: 'Bandwidth',
        bandwidthDesc: 'For transaction data transmission',
        energyLabel: 'Energy',
        energyDesc: 'For smart contract execution',
        estimatedFee: 'Estimated Fee',
        bandwidthFee: 'Bandwidth Fee',
        energyFee: 'Energy Fee',
        total: 'Total',

        // Rental Comparison
        costComparison: '💡 Energy Rental vs Direct Burn',
        directBurn: 'Direct Burn TRX',
        energyRental: 'Energy Rental',
        rentalNote: '* Rental price based on market average estimates',

        // Staking Calculator
        stakingTitle: 'Stake TRX for Energy',
        stakingDesc: 'Long-term holders can stake TRX to get free energy without paying fees each time',
        requiredStake: 'Required Stake',
        dailyTransfers: 'Daily Transfers',
        times: 'x',
        energyRecovery: 'Energy recovers every 24h',
        breakEven: 'Break Even',
        days: 'days',
        breakEvenNote: 'Based on 1 transfer per day',
        burnMethod: '🔥 Burn TRX',
        burnMethodDesc: 'Pay per transfer, no lock-up',
        stakeMethod: '🔒 Stake TRX',
        stakeMethodDesc: 'Best for long-term holders',
        recommended: 'Best',
        rentMethod: '⚡ Rent Energy',
        rentMethodDesc: 'Flexible savings, no lock-up',

        // Tips
        tip: 'Money-Saving Tips',
        trxTip: 'TRX transfers only consume bandwidth. Each account gets 600 free bandwidth daily. If insufficient, TRX will be burned automatically.',
        usdtTipHas: 'USDT (TRC20) transfers require energy and bandwidth. Stake TRX for free energy, or use third-party energy rental services to save 60%-90%.',
        usdtTipNo: 'First-time USDT recipients require token account creation, consuming ~2x energy. Send a small amount first to activate, halving future transfer costs.',

        // Footer
        dataSource: 'Data Sources: ',
        disclaimer: '⚠️ Fees shown are estimates. Actual fees may vary due to network conditions.',
    }
};

let currentLang = localStorage.getItem('lang') || 'zh';

/**
 * 获取翻译文本
 */
function t(key) {
    return translations[currentLang][key] || translations['zh'][key] || key;
}

/**
 * 更新页面所有文本
 */
function updatePageLanguage() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang][key]) {
            el.textContent = translations[currentLang][key];
        }
    });

    // 更新语言按钮文本
    const langText = document.getElementById('langText');
    if (langText) {
        langText.textContent = currentLang === 'zh' ? '中文' : 'EN';
    }

    // 更新 HTML lang 属性
    document.documentElement.lang = currentLang === 'zh' ? 'zh-CN' : 'en';
}

/**
 * 切换语言
 */
function toggleLanguage() {
    currentLang = currentLang === 'zh' ? 'en' : 'zh';
    localStorage.setItem('lang', currentLang);
    updatePageLanguage();

    // 触发自定义事件，通知其他模块语言已更改
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang: currentLang } }));
}

// 初始化语言
document.addEventListener('DOMContentLoaded', () => {
    updatePageLanguage();

    // 绑定语言切换按钮
    const langBtn = document.getElementById('langBtn');
    if (langBtn) {
        langBtn.addEventListener('click', toggleLanguage);
    }
});
