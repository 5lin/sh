/**
 * Tron Fee Calculator
 * 实时计算 Tron 网络上 TRX 和 USDT 转账的手续费
 */

// ===== 常量配置 =====
const CONFIG = {
    // TronGrid API (免费公共节点)
    TRONGRID_API: 'https://api.trongrid.io',

    // CoinGecko API 获取 TRX 价格
    COINGECKO_API: 'https://api.coingecko.com/api/v3',

    // USDT TRC20 合约地址
    USDT_CONTRACT: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',

    // 默认值（当 API 不可用时使用）
    DEFAULTS: {
        ENERGY_PRICE: 420,      // 能量单价 (sun)
        BANDWIDTH_PRICE: 1000,  // 带宽单价 (sun)
        TRX_PRICE_USD: 0.25,    // TRX 价格 (USD)
    },

    // 资源消耗估算
    RESOURCES: {
        // TRX 转账带宽消耗
        TRX_BANDWIDTH: 269,

        // USDT 转账 - 接收方已有 USDT
        USDT_ENERGY_EXISTING: 64_285,
        USDT_BANDWIDTH_EXISTING: 345,

        // USDT 转账 - 接收方首次接收 (需创建账户)
        USDT_ENERGY_NEW: 129_895,
        USDT_BANDWIDTH_NEW: 345,
    },

    // 能量租赁折扣（相对于直接燃烧的比例）
    ENERGY_RENTAL_RATIO: 0.35, // 租赁价格约为燃烧价格的 35%

    // SUN 单位转换 (1 TRX = 1,000,000 SUN)
    SUN_PER_TRX: 1_000_000,

    // 质押相关参数
    STAKING: {
        // 全网能量池（动态值，这里用近似值）
        TOTAL_ENERGY_LIMIT: 100_000_000_000, // 1000亿
        // 全网质押 TRX 总量（动态值，这里用近似值）
        TOTAL_FROZEN_TRX: 40_000_000_000, // 400亿 TRX
        // 能量每日恢复率
        DAILY_RECOVERY_RATE: 1, // 100% 24小时恢复
    },

    // 刷新间隔 (毫秒)
    REFRESH_INTERVAL: 60_000,
};

// ===== 状态管理 =====
const state = {
    transferType: 'trx',      // 'trx' | 'usdt'
    walletStatus: 'has-usdt', // 'has-usdt' | 'no-usdt'
    transferAmount: 0,        // 转账金额

    // 链上数据
    chainData: {
        energyPrice: CONFIG.DEFAULTS.ENERGY_PRICE,
        bandwidthPrice: CONFIG.DEFAULTS.BANDWIDTH_PRICE,
        trxPriceUsd: CONFIG.DEFAULTS.TRX_PRICE_USD,
        lastUpdate: null,
    },

    isLoading: false,
    isCheckingAddress: false,
};

// ===== DOM 元素引用 =====
let elements = {};

function initElements() {
    elements = {
        // 网络状态
        networkStatus: document.getElementById('networkStatus'),

        // 实时数据
        trxPrice: document.getElementById('trxPrice'),
        energyPrice: document.getElementById('energyPrice'),
        bandwidthPrice: document.getElementById('bandwidthPrice'),
        lastUpdate: document.getElementById('lastUpdate'),

        // 转账类型按钮
        trxBtn: document.getElementById('trxBtn'),
        usdtBtn: document.getElementById('usdtBtn'),

        // 地址查询
        addressSection: document.getElementById('addressSection'),
        addressInput: document.getElementById('addressInput'),
        checkAddressBtn: document.getElementById('checkAddressBtn'),
        addressStatus: document.getElementById('addressStatus'),

        // 金额输入
        amountSection: document.getElementById('amountSection'),
        amountInput: document.getElementById('amountInput'),
        amountUnit: document.getElementById('amountUnit'),
        feeRatio: document.getElementById('feeRatio'),

        // USDT 选项
        usdtOptions: document.getElementById('usdtOptions'),
        hasUsdtBtn: document.getElementById('hasUsdtBtn'),
        noUsdtBtn: document.getElementById('noUsdtBtn'),

        // 刷新按钮
        refreshBtn: document.getElementById('refreshBtn'),

        // 资源消耗
        bandwidthValue: document.getElementById('bandwidthValue'),
        energyRow: document.getElementById('energyRow'),
        energyValue: document.getElementById('energyValue'),

        // 费用
        bandwidthFee: document.getElementById('bandwidthFee'),
        energyFeeRow: document.getElementById('energyFeeRow'),
        energyFee: document.getElementById('energyFee'),
        totalTrx: document.getElementById('totalTrx'),
        totalUsd: document.getElementById('totalUsd'),

        // 能量租赁对比
        rentalComparison: document.getElementById('rentalComparison'),
        burnCost: document.getElementById('burnCost'),
        burnCostUsd: document.getElementById('burnCostUsd'),
        rentalCost: document.getElementById('rentalCost'),
        rentalCostUsd: document.getElementById('rentalCostUsd'),
        savingsBadge: document.getElementById('savingsBadge'),

        // 质押计算器
        stakingCalculator: document.getElementById('stakingCalculator'),
        requiredStake: document.getElementById('requiredStake'),
        requiredStakeUsd: document.getElementById('requiredStakeUsd'),
        dailyTransfers: document.getElementById('dailyTransfers'),
        breakEvenDays: document.getElementById('breakEvenDays'),

        // 提示
        tipText: document.getElementById('tipText'),
    };
}

// ===== API 调用 =====

/**
 * 获取 Tron 链参数（能量和带宽价格）
 */
async function fetchChainParameters() {
    try {
        const response = await fetch(`${CONFIG.TRONGRID_API}/wallet/getchainparameters`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        // 从链参数中提取能量和带宽价格
        let energyPrice = CONFIG.DEFAULTS.ENERGY_PRICE;
        let bandwidthPrice = CONFIG.DEFAULTS.BANDWIDTH_PRICE;

        if (data.chainParameter) {
            for (const param of data.chainParameter) {
                if (param.key === 'getEnergyFee') {
                    energyPrice = param.value;
                }
                if (param.key === 'getTransactionFee') {
                    bandwidthPrice = param.value;
                }
            }
        }

        return { energyPrice, bandwidthPrice };
    } catch (error) {
        console.error('获取链参数失败:', error);
        return {
            energyPrice: CONFIG.DEFAULTS.ENERGY_PRICE,
            bandwidthPrice: CONFIG.DEFAULTS.BANDWIDTH_PRICE,
        };
    }
}

/**
 * 获取 TRX 当前价格 (USD)
 */
async function fetchTrxPrice() {
    try {
        const response = await fetch(
            `${CONFIG.COINGECKO_API}/simple/price?ids=tron&vs_currencies=usd`,
            {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                },
            }
        );

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        return data.tron?.usd || CONFIG.DEFAULTS.TRX_PRICE_USD;
    } catch (error) {
        console.error('获取 TRX 价格失败:', error);
        return CONFIG.DEFAULTS.TRX_PRICE_USD;
    }
}

/**
 * 检查地址是否持有 USDT
 */
async function checkAddressUsdtBalance(address) {
    try {
        // 验证地址格式
        if (!address || !address.match(/^T[A-Za-z1-9]{33}$/)) {
            return { valid: false, hasUsdt: false, error: 'invalidAddress' };
        }

        // 调用 TronGrid API 获取 TRC20 余额
        const response = await fetch(
            `${CONFIG.TRONGRID_API}/v1/accounts/${address}/tokens?only_confirmed=true&limit=100`,
            {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                },
            }
        );

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        // 检查是否有 USDT
        if (data.data && Array.isArray(data.data)) {
            const hasUsdt = data.data.some(token =>
                token.tokenId === CONFIG.USDT_CONTRACT ||
                token.tokenAbbr === 'USDT' ||
                token.tokenName === 'Tether USD'
            );
            return { valid: true, hasUsdt, error: null };
        }

        return { valid: true, hasUsdt: false, error: null };
    } catch (error) {
        console.error('检查地址失败:', error);
        return { valid: true, hasUsdt: false, error: 'checkFailed' };
    }
}

/**
 * 刷新所有数据
 */
async function refreshData() {
    if (state.isLoading) return;

    state.isLoading = true;
    elements.refreshBtn?.classList.add('loading');
    updateNetworkStatus('connecting');

    try {
        // 并行获取所有数据
        const [chainParams, trxPrice] = await Promise.all([
            fetchChainParameters(),
            fetchTrxPrice(),
        ]);

        // 更新状态
        state.chainData = {
            energyPrice: chainParams.energyPrice,
            bandwidthPrice: chainParams.bandwidthPrice,
            trxPriceUsd: trxPrice,
            lastUpdate: new Date(),
        };

        // 更新 UI
        updateLiveDataDisplay();
        calculateAndDisplayFees();
        updateNetworkStatus('connected');

    } catch (error) {
        console.error('刷新数据失败:', error);
        updateNetworkStatus('error');
    } finally {
        state.isLoading = false;
        elements.refreshBtn?.classList.remove('loading');
    }
}

// ===== 费用计算 =====

/**
 * 计算转账费用
 */
function calculateFees() {
    const { energyPrice, bandwidthPrice, trxPriceUsd } = state.chainData;

    let bandwidth = 0;
    let energy = 0;

    if (state.transferType === 'trx') {
        // TRX 转账只消耗带宽
        bandwidth = CONFIG.RESOURCES.TRX_BANDWIDTH;
        energy = 0;
    } else {
        // USDT 转账
        if (state.walletStatus === 'has-usdt') {
            bandwidth = CONFIG.RESOURCES.USDT_BANDWIDTH_EXISTING;
            energy = CONFIG.RESOURCES.USDT_ENERGY_EXISTING;
        } else {
            bandwidth = CONFIG.RESOURCES.USDT_BANDWIDTH_NEW;
            energy = CONFIG.RESOURCES.USDT_ENERGY_NEW;
        }
    }

    // 计算费用 (单位: SUN)
    const bandwidthFeeSun = bandwidth * bandwidthPrice;
    const energyFeeSun = energy * energyPrice;
    const totalFeeSun = bandwidthFeeSun + energyFeeSun;

    // 转换为 TRX
    const bandwidthFeeTrx = bandwidthFeeSun / CONFIG.SUN_PER_TRX;
    const energyFeeTrx = energyFeeSun / CONFIG.SUN_PER_TRX;
    const totalFeeTrx = totalFeeSun / CONFIG.SUN_PER_TRX;

    // 转换为 USD
    const totalFeeUsd = totalFeeTrx * trxPriceUsd;

    // 能量租赁成本估算
    const rentalCostTrx = energyFeeTrx * CONFIG.ENERGY_RENTAL_RATIO;
    const rentalTotalTrx = bandwidthFeeTrx + rentalCostTrx;
    const rentalTotalUsd = rentalTotalTrx * trxPriceUsd;
    const savingsPercent = energy > 0 ? Math.round((1 - CONFIG.ENERGY_RENTAL_RATIO) * 100) : 0;

    return {
        bandwidth,
        energy,
        bandwidthFeeTrx,
        energyFeeTrx,
        totalFeeTrx,
        totalFeeUsd,
        rentalCostTrx: rentalTotalTrx,
        rentalCostUsd: rentalTotalUsd,
        savingsPercent,
    };
}

// ===== UI 更新 =====

/**
 * 更新网络状态显示
 */
function updateNetworkStatus(status) {
    if (!elements.networkStatus) return;

    elements.networkStatus.className = 'network-status';
    const statusText = elements.networkStatus.querySelector('.status-text');

    switch (status) {
        case 'connected':
            elements.networkStatus.classList.add('connected');
            if (statusText) statusText.textContent = t('connected');
            break;
        case 'error':
            elements.networkStatus.classList.add('error');
            if (statusText) statusText.textContent = t('connectionFailed');
            break;
        default:
            if (statusText) statusText.textContent = t('connecting');
    }
}

/**
 * 更新实时数据显示
 */
function updateLiveDataDisplay() {
    const { energyPrice, bandwidthPrice, trxPriceUsd, lastUpdate } = state.chainData;

    if (elements.trxPrice) elements.trxPrice.textContent = `$${trxPriceUsd.toFixed(4)}`;
    if (elements.energyPrice) elements.energyPrice.textContent = energyPrice.toLocaleString();
    if (elements.bandwidthPrice) elements.bandwidthPrice.textContent = bandwidthPrice.toLocaleString();

    if (lastUpdate && elements.lastUpdate) {
        const timeStr = lastUpdate.toLocaleTimeString(currentLang === 'zh' ? 'zh-CN' : 'en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });
        elements.lastUpdate.textContent = timeStr;
    }
}

/**
 * 计算并显示费用
 */
function calculateAndDisplayFees() {
    const fees = calculateFees();

    // 更新资源消耗
    if (elements.bandwidthValue) {
        elements.bandwidthValue.textContent = fees.bandwidth.toLocaleString();
    }

    if (state.transferType === 'usdt') {
        elements.energyRow?.classList.remove('hidden');
        elements.energyFeeRow?.classList.remove('hidden');
        elements.rentalComparison?.classList.remove('hidden');

        if (elements.energyValue) {
            elements.energyValue.textContent = fees.energy.toLocaleString();
        }
        if (elements.energyFee) {
            elements.energyFee.textContent = `${fees.energyFeeTrx.toFixed(2)} TRX`;
        }

        // 更新能量租赁对比
        if (elements.burnCost) {
            elements.burnCost.textContent = `${fees.totalFeeTrx.toFixed(2)} TRX`;
        }
        if (elements.burnCostUsd) {
            elements.burnCostUsd.textContent = `≈ $${fees.totalFeeUsd.toFixed(2)}`;
        }
        if (elements.rentalCost) {
            elements.rentalCost.textContent = `${fees.rentalCostTrx.toFixed(2)} TRX`;
        }
        if (elements.rentalCostUsd) {
            elements.rentalCostUsd.textContent = `≈ $${fees.rentalCostUsd.toFixed(2)}`;
        }
        if (elements.savingsBadge) {
            elements.savingsBadge.textContent = `${currentLang === 'zh' ? '节省' : 'Save'} ${fees.savingsPercent}%`;
        }
        // 更新质押计算器
        updateStakingCalculator(fees);
    } else {
        elements.energyRow?.classList.add('hidden');
        elements.energyFeeRow?.classList.add('hidden');
        elements.rentalComparison?.classList.add('hidden');
        elements.stakingCalculator?.classList.add('hidden');
    }

    // 更新费用
    if (elements.bandwidthFee) {
        elements.bandwidthFee.textContent = `${fees.bandwidthFeeTrx.toFixed(3)} TRX`;
    }
    if (elements.totalTrx) {
        elements.totalTrx.textContent = `${fees.totalFeeTrx.toFixed(2)} TRX`;
    }
    if (elements.totalUsd) {
        elements.totalUsd.textContent = `≈ $${fees.totalFeeUsd.toFixed(2)}`;
    }

    // 更新手续费占比
    updateFeeRatio(fees.totalFeeUsd);

    // 更新提示
    updateTip();
}

/**
 * 更新手续费占比
 */
function updateFeeRatio(feeUsd) {
    if (!elements.feeRatio) return;

    const amount = parseFloat(elements.amountInput?.value) || 0;

    if (amount > 0) {
        let amountUsd = amount;
        // 如果是 TRX，需要转换为 USD
        if (state.transferType === 'trx') {
            amountUsd = amount * state.chainData.trxPriceUsd;
        }

        const ratio = (feeUsd / amountUsd * 100).toFixed(2);
        const text = t('feeRatioText').replace('{ratio}', ratio);
        elements.feeRatio.textContent = text;
        elements.feeRatio.style.display = 'block';
    } else {
        elements.feeRatio.style.display = 'none';
    }
}

/**
 * 更新提示信息
 */
function updateTip() {
    if (!elements.tipText) return;

    if (state.transferType === 'trx') {
        elements.tipText.textContent = t('trxTip');
    } else {
        if (state.walletStatus === 'no-usdt') {
            elements.tipText.textContent = t('usdtTipNo');
        } else {
            elements.tipText.textContent = t('usdtTipHas');
        }
    }
}

/**
 * 更新质押计算器
 */
function updateStakingCalculator(fees) {
    if (!elements.stakingCalculator) return;

    // 显示质押计算器（仅 USDT 转账时）
    elements.stakingCalculator.classList.remove('hidden');

    const { trxPriceUsd } = state.chainData;
    const energyNeeded = fees.energy;

    // 计算需要质押多少 TRX 才能获得足够能量
    // 公式: 需要TRX = (需要能量 / 全网能量池) * 全网质押TRX
    const stakingRatio = energyNeeded / CONFIG.STAKING.TOTAL_ENERGY_LIMIT;
    const requiredTrx = Math.ceil(stakingRatio * CONFIG.STAKING.TOTAL_FROZEN_TRX);
    const requiredUsd = requiredTrx * trxPriceUsd;

    // 更新显示
    if (elements.requiredStake) {
        elements.requiredStake.textContent = `${requiredTrx.toLocaleString()} TRX`;
    }
    if (elements.requiredStakeUsd) {
        elements.requiredStakeUsd.textContent = `≈ $${requiredUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
    }

    // 每日可转账次数（能量 24 小时完全恢复）
    if (elements.dailyTransfers) {
        const timesText = currentLang === 'zh' ? '次' : 'x';
        elements.dailyTransfers.innerHTML = `1 <span data-i18n="times">${timesText}</span>`;
    }

    // 回本周期计算
    // 假设每天转账 1 次，每次节省 fees.totalFeeTrx
    if (elements.breakEvenDays) {
        const dailySavings = fees.totalFeeTrx; // 每天节省的 TRX
        const breakEvenDays = dailySavings > 0 ? Math.ceil(requiredTrx / dailySavings) : 999999;
        const daysText = currentLang === 'zh' ? '天' : 'days';

        if (breakEvenDays > 10000) {
            elements.breakEvenDays.innerHTML = `∞ <span data-i18n="days">${daysText}</span>`;
        } else {
            elements.breakEvenDays.innerHTML = `${breakEvenDays.toLocaleString()} <span data-i18n="days">${daysText}</span>`;
        }
    }
}

/**
 * 切换转账类型
 */
function switchTransferType(type) {
    state.transferType = type;

    // 更新按钮状态
    elements.trxBtn?.classList.toggle('active', type === 'trx');
    elements.usdtBtn?.classList.toggle('active', type === 'usdt');

    // 显示/隐藏相关区域
    elements.addressSection?.classList.toggle('hidden', type !== 'usdt');
    elements.amountSection?.classList.toggle('hidden', false); // 始终显示金额输入
    elements.usdtOptions?.classList.toggle('hidden', type !== 'usdt');

    // 更新金额单位
    if (elements.amountUnit) {
        elements.amountUnit.textContent = type === 'trx' ? 'TRX' : 'USDT';
    }

    // 重新计算费用
    calculateAndDisplayFees();
}

/**
 * 切换钱包状态
 */
function switchWalletStatus(status) {
    state.walletStatus = status;

    // 更新按钮状态
    elements.hasUsdtBtn?.classList.toggle('active', status === 'has-usdt');
    elements.noUsdtBtn?.classList.toggle('active', status === 'no-usdt');

    // 重新计算费用
    calculateAndDisplayFees();
}

/**
 * 检查地址
 */
async function handleCheckAddress() {
    const address = elements.addressInput?.value.trim();

    if (!address) {
        updateAddressStatus('', '');
        return;
    }

    if (state.isCheckingAddress) return;

    state.isCheckingAddress = true;

    if (elements.checkAddressBtn) {
        elements.checkAddressBtn.textContent = t('checking');
        elements.checkAddressBtn.disabled = true;
    }

    try {
        const result = await checkAddressUsdtBalance(address);

        if (!result.valid) {
            updateAddressStatus('error', t('invalidAddress'));
        } else if (result.error) {
            updateAddressStatus('warning', t(result.error));
        } else if (result.hasUsdt) {
            updateAddressStatus('success', t('hasUsdtStatus'));
            switchWalletStatus('has-usdt');
        } else {
            updateAddressStatus('warning', t('noUsdtStatus'));
            switchWalletStatus('no-usdt');
        }
    } catch (error) {
        updateAddressStatus('warning', t('checkFailed'));
    } finally {
        state.isCheckingAddress = false;
        if (elements.checkAddressBtn) {
            elements.checkAddressBtn.textContent = t('checkBtn');
            elements.checkAddressBtn.disabled = false;
        }
    }
}

/**
 * 更新地址状态显示
 */
function updateAddressStatus(type, message) {
    if (!elements.addressStatus) return;

    elements.addressStatus.className = 'address-status';
    if (type) {
        elements.addressStatus.classList.add(type);
    }
    elements.addressStatus.textContent = message;
}

// ===== 事件监听 =====

function setupEventListeners() {
    // 转账类型切换
    elements.trxBtn?.addEventListener('click', () => switchTransferType('trx'));
    elements.usdtBtn?.addEventListener('click', () => switchTransferType('usdt'));

    // 钱包状态切换
    elements.hasUsdtBtn?.addEventListener('click', () => switchWalletStatus('has-usdt'));
    elements.noUsdtBtn?.addEventListener('click', () => switchWalletStatus('no-usdt'));

    // 地址检查
    elements.checkAddressBtn?.addEventListener('click', handleCheckAddress);
    elements.addressInput?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleCheckAddress();
        }
    });

    // 金额输入
    elements.amountInput?.addEventListener('input', () => {
        state.transferAmount = parseFloat(elements.amountInput.value) || 0;
        calculateAndDisplayFees();
    });

    // 刷新按钮
    elements.refreshBtn?.addEventListener('click', refreshData);

    // 键盘快捷键
    document.addEventListener('keydown', (e) => {
        if (e.key === 'r' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            refreshData();
        }
    });

    // 语言切换事件
    window.addEventListener('languageChanged', () => {
        updateLiveDataDisplay();
        calculateAndDisplayFees();
    });
}

// ===== 初始化 =====

async function init() {
    console.log('🚀 Tron Fee Calculator 初始化中...');

    // 初始化 DOM 引用
    initElements();

    // 设置事件监听
    setupEventListeners();

    // 初始显示默认值
    updateLiveDataDisplay();
    calculateAndDisplayFees();

    // 获取实时数据
    await refreshData();

    // 定时刷新
    setInterval(refreshData, CONFIG.REFRESH_INTERVAL);

    console.log('✅ 初始化完成');
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', init);
