# Tron Fee Calculator

实时计算 Tron 网络上 TRX 和 USDT (TRC20) 转账所需的手续费。

## 功能特性

- 🔄 **实时数据** - 通过 TronGrid API 获取当前能量/带宽价格
- 💰 **TRX 价格** - 通过 CoinGecko API 获取实时 TRX/USD 价格
- 📊 **智能计算** - 区分 TRX 和 USDT 转账的不同费用
- 🎯 **精确估算** - 区分接收方是否已有 USDT（首次接收费用更高）
- 📱 **响应式设计** - 完美适配桌面和移动设备

## 费用说明

### TRX 转账
- 仅消耗带宽 (~269 Bandwidth)
- 每个账户每天有 600 免费带宽

### USDT (TRC20) 转账
- **接收方已有 USDT**: ~65,000 能量 + ~345 带宽
- **接收方首次接收**: ~130,000 能量 + ~345 带宽（需创建代币账户）

## 部署到 Cloudflare Pages

### 方式一：使用 Wrangler CLI

```bash
# 安装 Wrangler
npm install -g wrangler

# 登录 Cloudflare
wrangler login

# 部署
wrangler pages deploy . --project-name=tron-fee-calculator
```

### 方式二：GitHub 集成

1. 将此项目推送到 GitHub
2. 在 Cloudflare Dashboard 中连接 GitHub 仓库
3. 设置构建输出目录为 `/`（根目录）

### 方式三：拖拽上传

1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. 进入 Workers & Pages
3. 创建新项目，选择 "Upload assets"
4. 将项目文件夹拖拽上传

## 技术栈

- 纯静态 HTML/CSS/JavaScript
- 无需构建工具
- 无外部依赖（除 Google Fonts）

## API 使用

- **TronGrid API**: 获取链参数（能量/带宽价格）
- **CoinGecko API**: 获取 TRX 实时价格

## License

MIT
